﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class controlTutorial : MonoBehaviour {
	/// <summary>
	///Joints
	/// </summary>
	[Tooltip("The joints of the robot manipulator")]
	public GameObject j0, j1, j2,j3,j4,j5;
	[Space (5)]
	[Tooltip("link length of the manipulator")]
	public float a1= 14.05f;
	[Tooltip("link length of the manipulator")]
	public float a2 = 40.8f, a3 = 12.15f,a4 = 37.6f,a5 = 10.25f,a6 = 10.25f,a7 = 9.4f;
	[Header("Final Position")]
	public Vector3 finalPosition;
	[Header("The IK solution")]
	public float theta1;
	public float theta2, theta3,theta4,theta5,theta6;

	float phi1,phi2,phi3,r1,r2,r3;

	// Use this for initialization
	void Start () {
		GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
		cube.transform.position = new Vector3(finalPosition.x,finalPosition.z,finalPosition.y);
        cube.transform.localScale = new Vector3(2, 2, 2);

		j0.transform.Rotate (new Vector3(0,-theta1,0));
		j1.transform.Rotate (new Vector3(-theta2,0,0));
		j2.transform.Rotate (new Vector3(-theta3,0,0));
        j3.transform.Rotate(new Vector3(theta4, 0, 0));
        j4.transform.Rotate(new Vector3(0, theta5, 0));
        j5.transform.Rotate(new Vector3(theta6, 0, 0));



    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
