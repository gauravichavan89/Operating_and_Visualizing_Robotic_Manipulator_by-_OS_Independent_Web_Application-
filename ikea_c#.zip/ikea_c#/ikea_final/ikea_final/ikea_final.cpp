// ikea_final.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <cmath>
constexpr auto PI = 3.1416;

double sind(double a)
{
	double b = sin(a*PI / 180.0);
	return b;
}

double cosd(double a)
{
	double b = cos(a*PI / 180.0);
	return b;
}
double acosd(double a)
{
	double b = acos(a) * 180 / PI;
	return b;
}
double asind(double a)
{
	double b = asin(a) * 180 / PI;
	return b;
}
double atand(double a)
{
	double b = atan(a) * 180 / PI;
	return b;
}
double sq(double k)
{
	return k * k;
}
double sqrt(double k)
{
	return pow(k, 0.5);
}


int main()
{
	double a1 = 140.5;
	double a2 = 408;
	double a3 = 121.5;
	double a4 = 376;
	double a5 = 102.5;
	double a6 = 102.5;
	double a7 = 94;

	double px = 613.1261;
	double py = -347.2991;
	double pz = 547.6925;

	double mx = -0.4451;
	double my = 0.7578;
	double mz = -0.5514;

	double nx = -0.2496;
	double ny = -0.6423;
	double nz = -0.7247;

	double ox = -0.9033;
	double oy = -0.1152;
	double oz = 0.4132;

	double A = a1 - a3 + a5;
	double B = px + a7 * ox;
	double C = py + a7 * oy;

	A = a1 - a3 + a5;
	B = px + a7 * ox;
	C = py + a7 * oy;

	double sinTheta1 = ((A*C) + sqrt(sq(A*C) - (sq(B) + sq(C))*(sq(A) - sq(B)))) / (sq(B) + sq(C));
	double theta1 = asind(sinTheta1);
	std::cout << "\n Theta1 is: " << theta1;

	double theta5 = acosd(-cosd(theta1)*ox - oy * sind(theta1));
	std::cout << "\n Theta5 is: " << theta5;

	double theta6 = atand(-(cosd(theta1)*nx + ny * sind(theta1)) / (cosd(theta1)*mx + my * sind(theta1)));
	if ((cosd(theta1)*nx + ny * sind(theta1) == 0) && (cosd(theta1)*mx + my * sind(theta1) == 0)) {
		theta6 = 45;
		std::cout << "\n Theta6 is: " << theta6;
	} else {
		std::cout << "\n Theta6 is: " << theta6;
	}

	double L = (pz + a7 * oz + a6 * (cosd(theta6)*nz + mz * sind(theta6)));
	double K = a7 * (cosd(theta1)*oy - ox * sind(theta1)) + a6 * ((cosd(theta6)*(cosd(theta1)*ny - nx * sind(theta1))) + (sind(theta6)*(cosd(theta1)*my - mx * sind(theta1)))) + cosd(theta1)*py - px * sind(theta1);
	K = -K;
	double theta3 = acosd((sq(K) + sq(L) - sq(a2) - sq(a4)) / (2 * a2*a4));
	std::cout << "\n Theta3 is: " << theta3;

	double T = (sq(a4) - sq(K) - sq(L) - sq(a2)) / (2 * a2);
	double theta2 = acosd(((-2 * L*T + sqrt(4 * sq(L*T) - 4 * (sq(K) + sq(L))*(sq(T) - sq(K)))) / (2 * (sq(K) + sq(L)))));
	std::cout << "\n Theta2 is: " << theta2;

	double R = -(cosd(theta5)*(cosd(theta6)*mz - nz * sind(theta6))) - (oz*sind(theta5));
	double theta4 = asind(R) + theta2 + theta3;
	std::cout << "\n Theta4 is: " << theta4;

}


