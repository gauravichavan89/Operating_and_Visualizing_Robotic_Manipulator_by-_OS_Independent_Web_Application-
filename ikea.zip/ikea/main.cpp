#include <iostream>
#include <cmath>
#define PI 3.1416

using namespace std;

double sind(double a)
{
    double b = sin(a*PI/ 180.0);
    return b;
}

double cosd(double a)
{
    double b = cos(a*PI/ 180.0);
    return b;
}
double acosd(double a)
{
    double b = acos(a)*180/PI;
    return b;
}
double asind(double a)
{
    double b = asin(a)*180/PI;
    return b;
}
double sq(double k)
{
    return k*k;
}

int main()
{

double a1 = 140.5;
double a2=408;
double a3= 121.5;
double a4 = 376;
double a5 = 102.5;
double a6 = 102.5;
double a7 = 94;

double px = 613.1261;
double py =-347.2991;
double pz = 547.6925;

double mx = -0.4451;
double my = 0.7578;
double mz = -0.5514;

double nx = -0.2496;
double ny = -0.6423;
double nz = -0.7247;

double ox =-0.9033;
double oy =-0.1152;
double oz =0.4132;

double A = a1-a3+a5;
double B = px + a7 * ox;
double C = py + a7 * oy;

A = a1-a3+a5;
B = px + a7 * ox;
C = py + a7 * oy;

double G = A*C;
double squareAC = pow(G,2);
double squareA = pow(A,2);
double squareB = pow(B,2);
double squareC = pow(C,2);
double squareroot = sqrt(9);

double sinTheta1 = ((G)+ sqrt(squareAC-(squareB+squareC)*(squareA-squareB)))/(squareB+squareC);
double theta1 = asin (sinTheta1)* 180.0/ PI;
cout << " Theta1 is: " << theta1 << endl;

cout<<" costheta1 is: "<<cos(theta1* PI/ 180.0)<<endl;

double H = cos(theta1* PI/ 180.0)*ox;
double I = sin(theta1* PI/ 180.0)*oy;
double theta5=acos(-H-I)* 180.0/ PI;
cout<<" theta5 value:"<<theta5<<endl;

double J = cos(theta1* PI/ 180.0)*nx;
double K = ny*sin(theta1* PI/ 180.0);
double L = cos(theta1* PI/ 180.0)*mx;
double M = my*sin(theta1* PI/ 180.0);

double theta6 = atan(-(J+K)/(L+M))* 180.0/ PI;
   if( (J+K==0) && (L+M==0) ) {
        theta6 = 45;
      cout<<" theta6 value:"<<theta6<<endl;
   } else {
      cout<<" theta6 value:"<<theta6<<endl;
   }

   double N = cos(theta6* PI/ 180.0)*nz;
   double O = mz*sin(theta6* PI/ 180.0);
   double P = (pz + (a7*oz) +(a6*(N + O)));

   double Q = cos(theta1* PI/ 180.0)*oy;
   double R = ox*sin(theta1* PI/ 180.0);

   double S = cos(theta6* PI/ 180.0)*cos(theta1* PI/ 180.0)*ny;
   double T = nx*sin(theta1* PI/ 180.0);
   double U = sin(theta6* PI/ 180.0)*cos(theta1* PI/ 180.0)*my;
   double V = mx*sin(theta1* PI/ 180.0);
   double W = cos(theta1* PI/ 180.0)*py;
   double X = px*sin(theta1* PI/ 180.0);

   double Y = a7*(cosd(theta1)*oy - ox*sind(theta1)) + a6*((cosd(theta6)*(cosd(theta1)*ny - nx*sind(theta1))) + (sind(theta6)*(cosd(theta1)*my - mx*sind(theta1)))) + cosd(theta1)*py - px*sind(theta1);
   Y = -Y;
   double theta3 = acosd((pow(Y,2)+pow(P,2)-pow(a2,2)-pow(a4,2))/(2*a2*a4));
   cout<<" theta3 value:"<<theta3<<endl;

   double Z = (sq(a4) - sq(Y) -sq(P)-sq(a2))/(2*a2);
   double theta2 = acosd(((-2*P*Z + sqrt(4*sq(P*Z) - 4*(sq(Y)+sq(P))*(sq(Z)-sq(Y))))/(2*(sq(Y)+sq(P)))));
   cout<<" theta2 value:"<<theta2<<endl;

   double D = - (cosd(theta5)*(cosd(theta6)*mz - nz*sind(theta6))) - (oz*sind(theta5));
   double theta4 = asind(D) + theta2 + theta3;
   cout<<" theta4 value:"<<theta4<<endl;

   return 0;
}

