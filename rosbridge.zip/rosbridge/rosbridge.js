// Connecting to ROS
// -----------------
document.getElementById("sendPosition").addEventListener("click", sendPosition);

var inputX = document.getElementById("inputX");
var inputY = document.getElementById("inputY");
var inputz = document.getElementById("inputZ");
var inputXrotation = document.getElementById("inputXrotation");
var inputYrotation = document.getElementById("inputYrotation");
var inputZrotation = document.getElementById("inputZrotation");
floatXrotate = parseFloat(inputXrotation.value);
floatYrotate = parseFloat(inputXrotation.value);
floatZrotate = parseFloat(inputXrotation.value);
rx = [[1, 0, 0], [0, cosd(floatXrotate), -sind(floatXrotate)], [0, sind(floatXrotate), cosd(floatXrotate)]];
ry = [[cosd(floatYrotate), 0, sind(floatYrotate)], [0, 1, 0], [-sind(floatYrotate), 0, cosd(floatYrotate)]];
rz = [[cosd(floatZrotate), -sind(floatZrotate), 0], [sind(floatZrotate), cosd(floatZrotate), 0], [0, 0, 1]];

var rotationMatrix = matrixDot(matrixDot(rx, ry), rz);
var px = inputX.value;
var py = inputY.value;
var pz = inputZ.value;
var pz = groupAxis.position.y;
//This is the IP adress for the server to connect 
var ros = new ROSLIB.Ros({
    url: 'ws://192.168.43.88:9090'
});

ros.on('connection', function () {
    console.log('Connected to websocket server.');
});

ros.on('error', function (error) {
    console.log('Error connecting to websocket server: ', error);
});

ros.on('close', function () {
    console.log('Connection to websocket server closed.');
});

// Publishing a Topic
// ------------------

var cmdVel = new ROSLIB.Topic({
    ros: ros,
    name: '/cmd_vel',
    messageType: 'geometry_msgs/Twist'

});

//The position and orientation information to be sent to server from client 
var twist = new ROSLIB.Message({
    Mangular: {
        mx: rotationMatrix[0][0],
        my: rotationMatrix[0][1],
        mz: rotationMatrix[0][2]
    },
    Nangular: {
        nx: rotationMatrix[1][0],
        ny: rotationMatrix[1][1],
        nz: rotationMatrix[1][2]
    },
    Oangular: {
        ox: rotationMatrix[2][0],
        oy: rotationMatrix[2][1],
        oz: rotationMatrix[2][2]
    },
    position: {
        px: px,
        py: py,
        pz: pz
    }
});

//sending position function via buttonclick 
function sendPosition() {
    cmdVel.publish(twist);
}

// Subscribing to a Topic
// ----------------------
//listening to incoming message
var listener = new ROSLIB.Topic({
    ros: ros,
    name: '/listener',
    messageType: 'std_msgs/String'
});
var receivedMessage;
listener.subscribe(function (message) {
    console.log('Received message on ' + listener.name + ': ' + message.data);
    document.getElementById("receivedMessage").innerHTML = message.data;
    //listener.unsubscribe();
});

// Calling a service
// -----------------

var addTwoIntsClient = new ROSLIB.Service({
    ros: ros,
    name: '/add_two_ints',
    serviceType: 'rospy_tutorials/AddTwoInts'
});

var request = new ROSLIB.ServiceRequest({
    a: 1,
    b: 2
});

addTwoIntsClient.callService(request, function (result) {
    console.log('Result for service call on '
        + addTwoIntsClient.name
        + ': '
        + result.sum);
});

// Getting and setting a param value
// ---------------------------------
//This portion is not necessary for demo, but for actual robot this needs to change
ros.getParams(function (params) {
    console.log(params);
});

var maxVelX = new ROSLIB.Param({
    ros: ros,
    name: 'max_vel_y'
});
//
maxVelX.set(0.8);
maxVelX.get(function (value) {
    console.log('MAX VAL: ' + value);
});


